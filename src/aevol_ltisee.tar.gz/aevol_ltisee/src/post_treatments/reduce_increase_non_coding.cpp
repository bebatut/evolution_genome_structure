// ****************************************************************************
//
//          Aevol - An in silico experimental evolution platform
//
// ****************************************************************************
//
// Copyright: See the AUTHORS file provided with the package or <www.aevol.fr>
// Web: http://www.aevol.fr/
// E-mail: See <http://www.aevol.fr/contact/>
// Original Authors : Guillaume Beslon, Carole Knibbe, David Parsons
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
// ****************************************************************************


// ============================================================================
//                                   Includes
// ============================================================================
#include <cerrno>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cinttypes>
#include <cmath>

#include <getopt.h>
#include <zlib.h>
#include <sys/stat.h>

#include <list>

#include "aevol.h"
#include "IndivAnalysis.h"

using std::list;
using namespace aevol;

// Helper functions
void print_help(char* prog_path);
void interpret_cmd_line_options(int argc, char* argv[]);

// Command-line option variables
static int seed_           = 0;
static char* chromosome_file_name = nullptr;
static char* param_file_name_ = nullptr;


ParameterLine *line(int32_t* cur_line_ptr) // void
{
    char line[255];
    ParameterLine * formated_line = new ParameterLine();

    bool found_interpretable_line = false; // Found line that is neither a comment nor empty

    while (!feof(param_file_) && !found_interpretable_line)
    {
        if (!fgets(line, 255, param_file_))
        {
            delete formated_line;
            return NULL;
        }
        (*cur_line_ptr)++;
        format_line(formated_line, line, &found_interpretable_line);
    }

    if (found_interpretable_line)
    {
        return formated_line;
    }
    else
    {
        delete formated_line;
        return NULL;
    }
}

int main(int argc, char* argv[]) {
    interpret_cmd_line_options(argc, argv);

    // Initialize variables
    int mut_seed_       = 0;


    int32_t min_genome_length_   = 10;
    int32_t max_genome_length_   = 10000000;

    int32_t   chromosome_minimal_length_ = min_genome_length_;
    int32_t   chromosome_maximal_length_ = max_genome_length_;

    int id_new_indiv = 0;

    double w_max_              = 0.033333333;

    int16_t   env_sampling_ = 300;

    // Initialize the experiment manager
    ExpManager* exp_manager = new ExpManager();

    // Initialize the simulation from the parameter file
    int32_t lchromosome = -1;
    char* chromosome;

    if (chromosome_file_name != nullptr && param_in_file != nullptr) {
        // A. Read chromosome file
        const int max_input_chrom_size = 1000000;
        char raw_chromosome[max_input_chrom_size];
        FILE* chromosome_file = fopen(chromosome_file_name, "r");
        if (chromosome_file == nullptr) {
            printf("ERROR: failed to open source chromosome file %s\n",
                   chromosome_file_name);
            exit(EXIT_FAILURE);
        }
        if (fgets(raw_chromosome, max_input_chrom_size, chromosome_file) == nullptr)
        {
            printf("ERROR: failed to read from chromosome file %s\n",
                   chromosome_file_name);
            exit(EXIT_FAILURE);
        }
        lchromosome = strlen(raw_chromosome) - 1;
        chromosome = new char[lchromosome]; // Warning: will become the DNA of the
        // first individual created -> do not
        // delete, will be freed in Dna
        strncpy(chromosome, raw_chromosome, lchromosome);
        printf("Loading chromosome from text file %s (%" PRId32 " base pairs) \n",
                chromosome_file_name, lchromosome);
        fclose(chromosome_file);

        // B. Read param.in file
        std::list<Gaussian> std_env_gaussians;

        FILE*   param_file_;
        param_file_  = fopen(param_file_name_,  "r");

        if (param_file_ == NULL)
        {
            printf("ERROR : couldn't open file %s\n", file_name);
            exit(EXIT_FAILURE);
        }

        int32_t cur_line = 0;
        ParameterLine* parameter_line;

        while ((parameter_line = line(&cur_line)) != NULL) {
            if ((strcmp(parameter_line->words[0], "ENV_ADD_GAUSSIAN") == 0) ||
                (strcmp(parameter_line->words[0], "ENV_GAUSSIAN") == 0)) {
                std_env_gaussians.push_back(
                        Gaussian(atof(parameter_line->words[1]), atof(parameter_line->words[2]), atof(parameter_line->words[3])));
            } else {
                printf("ERROR in param file \"%s\" on line %"
                PRId32
                " : undefined key word \"%s\"\n", param_file_name_, cur_line, parameter_line->words[0]);
                exit(EXIT_FAILURE);
            }
        }

        // O. Build Phenotypic target
        Habitat habitat;

        PhenotypicTargetHandler& phenotypic_target_handler =
                habitat.phenotypic_target_handler_nonconst();

        phenotypic_target_handler.set_gaussians(std_env_gaussians);

        phenotypic_target_handler.set_sampling(env_sampling_);

        phenotypic_target_handler.BuildPhenotypicTarget();

        // 1. Create individual from file
        auto prng_ = std::make_shared<JumpingMT>(seed_);

        if (mut_seed_ == 0) {
            mut_seed_ = prng_->random(1000000);
        }

        int stoch_seed_ = prng_->random(1000000);

        auto mut_prng   = std::make_shared<JumpingMT>(mut_seed_);
        auto stoch_prng = std::make_shared<JumpingMT>(stoch_seed_);

        auto param_mut = std::make_shared<MutationParams>();

        Individual* indiv = new Individual(exp_m,
                                           mut_prng,
                                           stoch_prng,
                                           param_mut,
                                           w_max_,
                                           min_genome_length_,
                                           max_genome_length_,
                                           false,
                                           id_new_indiv++,
                                           "reduce",
                                           0);

        indiv->add_GU(chromosome, lchromosome);
        indiv->genetic_unit_nonconst(0).set_min_gu_length(chromosome_minimal_length);
        indiv->genetic_unit_nonconst(0).set_max_gu_length(chromosome_maximal_length);
        indiv->EvaluateInContext(habitat);
        // 2. Reduce by 10% step non coding
        for (int i = 0; i < 100; i+=10) {
            // 3. Do point deletion that does not modify the metabolic error until reaching the reduce of x% of non coding
            Individual* indiv_clone = Individual::CreateClone(indiv, id_new_indiv++);
            Individual* indiv_last = Individual::CreateClone(indiv, id_new_indiv++);

            bool step_reach = false
            while (!step_reach) {
                // 3.1. Do small deletion
                // Determine the position and size of the small deletion
                int32_t pos = indiv_clone->mut_prng_->random(length_);
                int16_t nb_del = 1;

                indiv_clone->enetic_unit_nonconst(0).dna->do_small_deletion(pos, nb_del);
                indiv_clone->EvaluateInContext(habitat);

                if (indiv_last->dist_to_target_by_feature_[METABOLISM] != indiv_clone->dist_to_target_by_feature_[METABOLISM]) {

                }
            }

            // 4. Save the chromosome to txt (chromosome_file_reduce_non_coding_X with X the percentage)

        }
    } else {



    }




    delete exp_manager;
}


/**
 * \brief print help and exist
 */
void print_help(char* prog_path) {
  // Get the program file-name in prog_name (strip prog_path of the path)
  char* prog_name; // No new, it will point to somewhere inside prog_path
  if ((prog_name = strrchr(prog_path, '/'))) {
    prog_name++;
  }
  else {
    prog_name = prog_path;
  }

  printf("******************************************************************************\n");
  printf("*                                                                            *\n");
  printf("*                        aevol - Artificial Evolution                        *\n");
  printf("*                                                                            *\n");
  printf("* Aevol is a simulation platform that allows one to let populations of       *\n");
  printf("* digital organisms evolve in different conditions and study experimentally  *\n");
  printf("* the mechanisms responsible for the structuration of the genome and the     *\n");
  printf("* transcriptome.                                                             *\n");
  printf("*                                                                            *\n");
  printf("******************************************************************************\n");
  printf("\n");
  printf("%s: from a given chromosome, reduce by steps the quantity of non-coding DNA.\n",
         prog_name);
  printf("\n");
  printf("Usage : %s -h or --help\n", prog_name);
  printf("   or : %s -V or --version\n", prog_name);
  printf("   or : %s -C CHROM_FILE\n",
         prog_name);
  printf("\nOptions\n");
  printf("  -h, --help\n\tprint this help, then exit\n");
  printf("  -V, --version\n\tprint version number, then exit\n");
  printf("  -C, --chromosome CHROM_FILE\n");
  printf("  -S, --seed SEED_NUMBER\n");
  printf("  -f, --file PARAM_FILE\n");
  printf("\tload chromosome from given text file instead of generating it\n");
}

void interpret_cmd_line_options(int argc, char* argv[]) {
  const char* options_list = "hVf:SC:::";
  static struct option long_options_list[] = {
      {"help",       no_argument,       NULL, 'h'},
      {"version",    no_argument,       NULL, 'V'},
      {"chromosome", required_argument, nullptr, 'C'},
      {"seed",  required_argument, nullptr, 's'},
      {"file",       required_argument, nullptr, 'f'},
      {0, 0, 0, 0}
  };

  int option;
  while ((option = getopt_long(argc, argv, options_list, long_options_list,
                               NULL)) != -1) {
    switch (option) {
      case 'h' :
        print_help(argv[0]);
        exit(EXIT_SUCCESS);
      case 'V' :
        Utils::PrintAevolVersion();
        exit(EXIT_SUCCESS);
      case 'C': {
        chromosome_file_name = new char[strlen(optarg) + 1];
        strcpy(chromosome_file_name, optarg);
        break;
      }
      case 'S' : {
        seed_ = atoi(optarg);
        break;
      }
      case 'f' : {
        param_file_name = new char[strlen(optarg) + 1];
        strcpy(param_file_name, optarg);
        break;
      }
      default :
        // An error message is printed in getopt_long, we just need to exit
        exit(EXIT_FAILURE);
    }
  }
}
