This directory contains source files for post-treatments that are
not being compiled at the moment, but that we want to keep around
in case we need them in the future.
