 =================================================================
 SFMT ver. 1.4
 SIMD oriented Fast Mersenne Twister(SFMT)

 Mutsuo Saito (Hiroshima University) and
 Makoto Matsumoto (The University of Tokyo)

 Copyright (C) 2006, 2007 Mutsuo Saito, Makoto Matsumoto and Hiroshima
 University.
 Copyright (c) 2012 Mutsuo Saito, Makoto Matsumoto, Hiroshima University
 and The University of Tokyo.
 All rights reserved.

 The (modified) BSD License is applied to this software, see LICENSE.txt
 =================================================================
 CAUTION:
 BIGENDIAN OR ALTIVEC FEATURES ARE NOT TESTED AT ALL.

 If you want to redistribute and/or change source files, see LICENSE.txt.
 
 This is a partial redistribution of SFMT and SFMT_Jump.
 For full support, check http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/SFMT/#SFMT
