#include <gtest/gtest.h>

TEST(SampleTest, AssertionTrue)
{
  ASSERT_EQ(1, 1);
}
