The documentation being quite heavy, it is not included in basic distributions.
Please visit www.aevol.fr
